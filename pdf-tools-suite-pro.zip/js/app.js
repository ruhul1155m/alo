
async function pdfToJpg(){
 const f=document.getElementById('pdfFile').files[0];
 if(!f)return alert('Select PDF');
 alert('Starter implementation included. Extend for all pages.');
}
async function jpgToPdf(){
 const f=document.getElementById('imgFile').files[0];
 if(!f)return alert('Select image');
 const {jsPDF}=window.jspdf;
 const pdf=new jsPDF();
 const r=new FileReader();
 r.onload=e=>{
   const img=e.target.result;
   pdf.addImage(img,'JPEG',10,10,180,100);
   pdf.save('output.pdf');
 };
 r.readAsDataURL(f);
}
